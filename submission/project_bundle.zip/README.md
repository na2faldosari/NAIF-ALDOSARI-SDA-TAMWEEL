# Tamweel Lite | تمويل لايت

[![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/1gFq8oMK6yUSCPfUD1HMygbfTQD3gmM3J)

**Can information available at application time help rank financing requests by 90-day default risk?**

Tamweel Lite is a project for **Advanced Machine Learning Methods (SDA-DSC-211)** at SDAIA Academy. It uses synthetic financing applications to rank 90-day default risk and flag requests for human review within a fixed capacity. **Trainee code** `211`.

The final model is **Logistic Regression**. Its batch policy flagged **300 of 2,500** challenge requests for simulated review, within the **12%** limit.

[Open the executed project notebook](notebooks/delivery/NAIF_ALDOSARI_SDA_TAMWEEL_FINAL.ipynb) · [Day 1](#day-1-results) · [Day 2](#day-2-results) · [Day 3](#day-3-results) · [Day 4](#day-4-results) · [Day 5](#day-5-results) · [Daily answers](#daily-answers--الإجابات-اليومية) · [Figure sources](reports/FIGURES.md)

## Project roadmap

| Stage | Question | Progress |
| --- | --- | --- |
| 00 · Readiness | Does Colab have the required packages, and do the course data and tools work? | `READY` on CPU |
| 01 · Baseline and boosting | Which of the three models is the strongest candidate on the comparison set? | `TECHNICAL_READY` |
| 02 · Validation and tuning | How do leakage, time and customer separation affect the comparison? | `TECHNICAL_READY` |
| 03 · Cost-sensitive decisions | How do error costs and review capacity affect the threshold? | `TECHNICAL_READY` |
| 04 · Explanation and calibration | What drives the predictions, and how well do the probabilities reflect observed risk? | `TECHNICAL_READY` |
| 05 · Final model and export | Which model and decision policy should be exported with the documented evidence? | `TECHNICAL_READY · KEEP SINGLE` |

## Readiness and reproduction

The readiness run passed on Colab CPU with **10,000 training applications**. The data checks and six compatibility checks passed. The setup cell at the top of the project notebook prepares the package versions required by the course.

1. Open the [executed notebook in GitHub](notebooks/delivery/NAIF_ALDOSARI_SDA_TAMWEEL_FINAL.ipynb) to review its saved tables and figures.
2. Open the [project notebook in Google Colab](https://colab.research.google.com/drive/1gFq8oMK6yUSCPfUD1HMygbfTQD3gmM3J), use a CPU runtime and run from the top with `FAST_MODE=True`. If the setup cell restarts the session, run from the top again.
3. Check for `TECHNICAL_READY` after the export cell. The course code uses seed `211` and fetches the course files. Compare the [Day 1 model table](artifacts/day1_model_comparison.csv), [Day 2 validation summary](artifacts/validation_summary.csv), [Day 3 threshold metrics](artifacts/threshold_metrics.json), [Day 4 calibration metrics](artifacts/calibration_metrics.json), and [Day 5 final metrics](artifacts/final_metrics.json). Training times can vary between sessions.

## Day 1 results

Day 1 used 22 approved predictors to rank applications by the risk of `default_within_90d`. The outer split reserved 8,000 applications for development and 2,000 for comparison. Inside development, 6,000 applications were used to fit the boosting models while 2,000 were used for early stopping. The selected tree counts were fixed before refitting on all 8,000 development applications.

| Model | Average Precision | ROC-AUC | Training time (s) | Selected trees |
| --- | ---: | ---: | ---: | ---: |
| Logistic Regression | 0.3258 | **0.8213** | 0.0891 | — |
| XGBoost | **0.3338** | 0.8124 | 0.4918 | 61 |
| LightGBM | 0.3248 | 0.8138 | 0.3399 | 41 |

Of the 2,000 comparison applications, 158 defaulted within the target window (**7.9%**). Average Precision focuses on how well the models retrieve this rare class across score cutoffs. ROC-AUC measures ranking across both classes. Logistic Regression led on ROC-AUC, while XGBoost led on Average Precision by 0.0080 over the baseline. Boosting times include tree selection and refitting.

![ROC and precision–recall curves comparing the three Day 1 models](reports/day1_roc_pr.png)

### Evidence in this repository

| File | What to look for |
| --- | --- |
| [Day 1 notebook](notebooks/delivery/NAIF_ALDOSARI_SDA_TAMWEEL_DAY_01.ipynb) | The executed baseline and boosting comparison |
| [Model comparison](artifacts/day1_model_comparison.csv) | The three models evaluated on the same 2,000 applications |

## Day 2 results

[Executed Day 2 notebook](notebooks/delivery/NAIF_ALDOSARI_SDA_TAMWEEL_DAY_02.ipynb)

Day 2 used LightGBM to compare four validation protocols. The feature audit identified two post-application fields, `days_past_due_60` and `collection_calls`. Removing them left 22 approved predictors. The duplicate check found zero duplicates among 10,000 applications. Each forward fold used training labels whose 90-day outcome windows closed before validation began.

| Validation start | Eligible training applications | Validation applications | Shared customers |
| --- | ---: | ---: | ---: |
| July 2023 | 3,223 | 1,632 | 0 |
| January 2024 | 4,460 | 1,674 | 0 |
| July 2024 | 5,731 | 1,733 | 0 |

Optuna completed all 8 trials on 1,935 reserved historical applications. The search excluded all outer-validation customers. Its best internal mean AP was 0.3333, with a learning rate of 0.0853 (rounded), 31 leaves, and 40 minimum child samples. Those settings were fixed before outer evaluation. Each forward run covered all 5,039 eligible validation applications, or 50.39% of the dataset.

| Validation protocol | Mean AP ± SD | Mean ROC-AUC ± SD |
| --- | ---: | ---: |
| Leaky random control | 0.9988 ± 0.0014 | 0.9999 ± 0.0002 |
| Clean random control | 0.3110 ± 0.0293 | 0.8010 ± 0.0200 |
| Time- and customer-aware, fixed LightGBM | **0.3153 ± 0.0426** | **0.7976 ± 0.0206** |
| Time- and customer-aware, tuned LightGBM | 0.3133 ± 0.0259 | 0.7855 ± 0.0232 |

![Day 2 validation comparison showing the effect of leakage and the scores of both LightGBM configurations](reports/day2_validation_comparison.png)

The random controls show how much the evaluation changed when we removed post-application fields and fit imputation inside training. Mean AP fell from 0.9988 to 0.3110, a gap of 0.6879 calculated before rounding. The clean random and forward protocols cover different applications. Within the same three forward folds, fixed LightGBM scored slightly higher on both means, while tuned LightGBM had less AP variation. The bars show the sample standard deviation across folds.

| Evidence | What to check |
| --- | --- |
| [Leakage audit](artifacts/leakage_audit.csv) | Which fields were available when the application arrived |
| [Fold audit](artifacts/fold_audit.csv) | Three validation windows, zero shared customers and the training label cutoff |
| [Optuna trials](artifacts/optuna_results.csv) | Eight live trials and their internal fold scores |
| [Validation summary](artifacts/validation_summary.csv) | Mean and sample standard deviation for AP and ROC-AUC |

## Day 3 results

[Executed Day 3 notebook](notebooks/delivery/NAIF_ALDOSARI_SDA_TAMWEEL_DAY_03.ipynb) · [Decision card](reports/DECISION_CARD.md)

Day 3 used the forward, customer-separated validation design from Day 2. The unweighted, weighted and oversampled LightGBM variants each predicted the same 5,039 eligible applications out of fold. Defaults accounted for 7.62% of those applications. Screening nobody would reach 92.38% accuracy with zero recall. Pooled Average Precision was 0.3091, 0.3100 and 0.3159, respectively. The weighted variant was specified in advance for the threshold exercise.

The exercise assigns ten loss units to a missed default and one to a false flag (`10 × FN + FP`). The review ceiling is 12% **in each period**. A flagged application goes to simulated review.

| Rule | Threshold (rounded) | Reviews out of 5,039 | Recall | Precision | Loss units | Meets all period limits |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| Default | 0.50000 | 1,005 | 57.81% | 22.09% | 2,403 | No |
| Lowest loss before applying capacity | 0.44864 | 1,141 | 64.06% | 21.56% | 2,275 | No |
| Lowest loss within capacity | **0.65835** | **526** | 40.89% | 29.85% | 2,639 | **Yes** |

![Day 3 loss and review load across thresholds, with the feasible cutoff marked](reports/day3_cost_curve.png)

The chart normalizes loss per 10,000 applications. The table reports totals on the 5,039 OOF applications.

The capacity-constrained cutoff incurs 236 more loss units than 0.5 while keeping each period within its review limit. The busiest period flags 206 of 1,733 applications (**11.89%**), one below its cap of 207. Under the shared cutoff, the largest difference in regional false-positive rates is 0.65 percentage points. The regional comparison is descriptive. The threshold was selected and evaluated on the same OOF development scores.

| Evidence | What to check |
| --- | --- |
| [Threshold metrics](artifacts/threshold_metrics.json) | Exact cutoff, confusion counts and the three operating points |
| [Threshold sweep](artifacts/threshold_sweep.csv) | Loss and feasibility for each candidate cutoff |
| [Region audit](artifacts/day3_region_audit.csv) | False-positive rates for the four synthetic regions |

## Day 4 results

[Executed Day 4 notebook](notebooks/delivery/NAIF_ALDOSARI_SDA_TAMWEEL_DAY_04.ipynb) · [Interpretability report](reports/INTERPRETABILITY_REPORT.md)

Day 4 used separate, customer-disjoint periods for model fit (2,516 applications), sigmoid calibration (584), threshold selection (589), and evaluation (1,733). The calibration and threshold were frozen before evaluation. The weighted LightGBM helps demonstrate explanations and probability calibration ahead of the final model comparison.

`bureau_score` ranked first among 22 features in live SHAP on 300 evaluation applications (mean absolute contribution **0.9042 raw log-odds**). It also caused the largest mean drop in evaluation AP when shuffled (**0.1270**). For the highest-scoring application in the sample, the waterfall's largest positive contributions came from `bureau_score`, `dti` and `loan_amount_sar`.

![Day 4 SHAP beeswarm showing global importance and contributions to the raw model score](reports/day4_shap_beeswarm.png)

| Evaluation metric | Raw | After sigmoid |
| --- | ---: | ---: |
| Brier score | 0.11303 | **0.06711** |
| Expected Calibration Error (ECE) | 0.14687 | **0.02249** |
| ROC-AUC | 0.77080 | 0.77080 |
| Average Precision | 0.25868 | 0.25868 |

Probability agreement improved on the evaluation split, and the increasing sigmoid preserved the ranking. The 95% customer-bootstrap interval for the change in Brier was **−0.05418 to −0.03741**, conditional on the fixed model and calibrator in this sample.

The cutoff selected on the policy split maps from **0.58820** raw to **0.17331** calibrated (rounded), preserving the flagged set. The candidate review queue, combining flags and requests in the diagnostic band, exceeded capacity in both evaluation quarters (**109/100** in Q3 and **122/107** in Q4). Q4 also exceeded capacity on risk flags alone (**109/107**). The run reached `TECHNICAL_READY` with `CAPACITY_REVIEW_REQUIRED`. The evaluation records the exceedance with the selected cutoff left in place.

| Evidence | What to check |
| --- | --- |
| [Permutation importance](artifacts/permutation_importance.csv) | How much evaluation AP dropped when each feature group was shuffled |
| [Local SHAP waterfall](reports/day4_shap_waterfall.png) | Why the raw model gave one synthetic application a high score |
| [Reliability curve](reports/day4_reliability_curve.png) | Predicted probabilities versus observed rates and counts by bin |
| [Calibration metrics](artifacts/calibration_metrics.json) | Brier, ECE, exact cutoffs and review capacity status |

## Day 5 results

[Executed Day 5 lab](notebooks/delivery/NAIF_ALDOSARI_SDA_TAMWEEL_DAY_05.ipynb) · [Model card](reports/MODEL_CARD.md) · [Ensemble decision](reports/ENSEMBLE_DECISION.md) · [Project bundle](submission/project_bundle.zip)

The final lab compared three individual models and three ensembles on **2,155 out-of-fold (OOF) predictions** across three forward periods. Each validation period followed its training data, with a 90-day label-maturity gap and customer separation. The Day 4 weighted LightGBM remains the model explained in that lab. Day 5 compared all six candidates under its own validation design and selected **Logistic Regression** with `KEEP SINGLE`.

| Candidate | Mean AP | Fold SD | Mean Brier | Mean ECE |
| --- | ---: | ---: | ---: | ---: |
| LightGBM | 0.34549 | 0.04348 | 0.06608 | 0.02311 |
| XGBoost | 0.34714 | 0.03817 | 0.06577 | 0.02309 |
| **Logistic Regression** | **0.39166** | **0.02981** | **0.06327** | **0.01882** |
| Equal blend | 0.36780 | 0.03751 | 0.06436 | 0.02097 |
| Weighted blend | 0.38765 | 0.03060 | 0.06347 | 0.01913 |
| Stack | 0.38279 | 0.03423 | 0.06606 | 0.03119 |

![Day 5 comparison of mean Average Precision, fold standard deviation, Brier score and calibration error across all six candidates](reports/day5_ensemble_comparison.png)

AP measures how well a model ranks default cases. Brier and ECE summarize probability agreement, with lower values preferred. The Worth-It Gate required an AP lift greater than **0.02981**, with Brier worsening by at most **0.005** and ECE by at most **0.010**. The weighted blend had the highest AP among ensembles and was **0.00401 below** Logistic Regression. Fold SD describes variation across the three folds.

The raw threshold **0.16892** produced **1,111 OOF loss units** (`10 × 95 FN + 161 FP`) and flagged **245 of 2,155** labeled OOF rows. All three OOF periods were within the 12% review ceiling. The sigmoid mapped the cutoff to **0.12226**. On its own 836-row fit set, Brier moved from **0.07647 to 0.07806** and ECE from **0.02112 to 0.03487**. Those figures are fit diagnostics.

The exported model scored all **2,500** challenge applications. The threshold made 330 eligible for review. The batch cap retained 300, exactly **12%**. Replay reproduced every decision and matched submitted probabilities within `1e-12`. The challenge set has no labels for evaluating AP or error costs.

| Evidence | What it records |
| --- | --- |
| [Ensemble comparison](artifacts/ensemble_comparison.csv) | Ranking and calibration metrics used by the gate |
| [Final metrics](artifacts/final_metrics.json) · [Frozen policy](artifacts/final_policy.json) | OOF loss and regional diagnostics, calibration and the challenge cap |
| [Model export](artifacts/final_model/model.json) · [Submission CSV](submission/submission.csv) | Frozen model and one score and simulated review flag per challenge application |

## Daily answers | الإجابات اليومية

### Day 1 | اليوم الأول

I picked XGBoost for now. Only 7.9% of the requests in the comparison set defaulted, so I paid more attention to how well each model ranked those cases. XGBoost had the highest Average Precision at 0.3338, just ahead of Logistic Regression at 0.3258. The gap was small, so I’ll see if it holds up on Day 2.

**Why I changed the validation.** The Day 1 split separated application rows, but 1,226 customers still appeared in both development and comparison. Day 2 addressed that overlap and time ordering using LightGBM as the course lab’s common model. The comparison across Day 1’s three models still stands as a baseline for that original split.

### Day 2 | اليوم الثاني

I found that `collection_calls` counted contacts made after the application. I removed it and `days_past_due_60` because neither was known when the applicant applied. The leaky random control scored 0.9988 mean AP, compared with 0.3110 for the clean random control. The clean run also learned its imputation medians inside training. For the later validation windows, I excluded those customers from training and used only earlier applications whose 90-day outcome window had already closed. All three folds had zero shared customers.

### Day 3 | اليوم الثالث

I moved the review threshold above 0.5 because the weighted model sent 1,005 of 5,039 applications to review at that cutoff. The busiest period reached 23.20%, well above the 12% ceiling. I chose 0.65835 (rounded) because it gave the lowest simulated loss among the thresholds that met the ceiling in every period. It flagged 526 applications and produced 2,639 loss units, 236 more than 0.5. Missing a default costs ten times as much as a false flag in this exercise, so limiting the queue means accepting more missed defaults. Each flag sends an application to simulated review.

### Day 4 | اليوم الرابع

`bureau_score`, the synthetic credit score available at application time, was the most important feature in my explanation. It had the largest mean absolute SHAP value across 300 evaluation applications (0.9042 raw log-odds). Shuffling it also caused the largest average drop in Average Precision (0.1270). Both results show how much the fitted model relied on the score. They do not show that changing the score would change someone's default risk. Credit score can reflect other correlated factors, and this lab did not test an intervention.

### Day 5 | اليوم الخامس

I kept Logistic Regression because it had the highest mean Average Precision across the three forward folds (0.3917) and the lowest mean Brier score (0.0633) and ECE (0.0188). The strongest ensemble was the weighted blend at 0.3877 AP, 0.0040 below Logistic Regression. The Worth-It Gate required an AP gain greater than the best single model’s fold standard deviation (0.0298), plus limits on worsening calibration. None of the ensembles improved AP, so there was no measured gain to justify the extra models. These folds supported model selection. The unlabeled challenge batch was used to verify the export and review-cap policy.

## Final submission evidence

The [cumulative notebook](notebooks/delivery/NAIF_ALDOSARI_SDA_TAMWEEL_FINAL.ipynb) brings together the five days. Each [daily notebook](notebooks/delivery) covers that day’s lab and includes its own notes, outputs and answer. The `00` notebook provides the setup check for a fresh runtime.

| Day | Executed notebook | Main evidence |
| --- | --- | --- |
| 1 · Baseline and boosting | [Day 1](notebooks/delivery/NAIF_ALDOSARI_SDA_TAMWEEL_DAY_01.ipynb) | [Model comparison](artifacts/day1_model_comparison.csv) |
| 2 · Validation and tuning | [Day 2](notebooks/delivery/NAIF_ALDOSARI_SDA_TAMWEEL_DAY_02.ipynb) | [Validation report](artifacts/validation_report.csv) · [OOF coverage](artifacts/day2_oof_coverage.csv) |
| 3 · Cost and capacity | [Day 3](notebooks/delivery/NAIF_ALDOSARI_SDA_TAMWEEL_DAY_03.ipynb) | [Decision Card](reports/DECISION_CARD.md) · [Period capacity](artifacts/day3_period_capacity.csv) |
| 4 · Explanation and calibration | [Day 4](notebooks/delivery/NAIF_ALDOSARI_SDA_TAMWEEL_DAY_04.ipynb) | [Interpretability Report](reports/INTERPRETABILITY_REPORT.md) · [Global SHAP values](artifacts/day4_shap_global.csv) |
| 5 · Model and delivery | [Day 5](notebooks/delivery/NAIF_ALDOSARI_SDA_TAMWEEL_DAY_05.ipynb) | [Ensemble Decision](reports/ENSEMBLE_DECISION.md) · [Model Card](reports/MODEL_CARD.md) · [Challenge submission](submission/submission.csv) |

[Final presentation](presentation/final_presentation.pdf) · [Inference entry point](tamweel/inference.py) · [Project bundle](submission/project_bundle.zip) · [Official Notebook 99](notebooks/99_final_submission_check.ipynb)

## Scope and references

[Course portal](https://almiyead-rgb.github.io/advanced-machine-learning-methods-sda-dsc-211/) · [Day 1 guide](https://github.com/almiyead-rgb/sda-dsc-211-student-template/blob/main/DAY1_GUIDE.md) · [Day 2 guide](https://github.com/almiyead-rgb/sda-dsc-211-student-template/blob/main/DAY2_GUIDE.md) · [Day 3 guide](https://github.com/almiyead-rgb/sda-dsc-211-student-template/blob/main/DAY3_GUIDE.md) · [Day 4 guide](https://github.com/almiyead-rgb/sda-dsc-211-student-template/blob/main/DAY4_GUIDE.md) · [Day 5 guide](https://github.com/almiyead-rgb/sda-dsc-211-student-template/blob/main/DAY5_GUIDE.md) · [SDAIA Academy on GitHub](https://github.com/SDAIAAcademy)

Course materials and lab code are by Meaad Al-Marri. [Course template and notice](https://github.com/almiyead-rgb/sda-dsc-211-student-template/blob/main/NOTICE.md).
